package com.sliderdemo;






import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;



import android.widget.Toast;





import com.sliderdemo.util.FilterAnimation;

public class MainActivity extends Activity implements OnClickListener{

	RelativeLayout findLayout;
	FilterAnimation filterAnimation;
	LinearLayout btFilter, filterLayout,custombarclick;
	static RelativeLayout mainbackground;
	Button sliderbutton;
	
	ImageView imagetouch;
	
	boolean ischeck = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		init();
		
	}

	private void init() {
		// TODO Auto-generated method stub
		mainbackground = (RelativeLayout) findViewById(R.id.mainlayoutbackgound);
		findLayout = (RelativeLayout) findViewById(R.id.find_layout);
		btFilter = (LinearLayout) findViewById(R.id.filter);
		filterLayout = (LinearLayout) findViewById(R.id.filter_layout);
		filterAnimation = new FilterAnimation(this);
		sliderbutton= (Button)findViewById(R.id.btn_Profile);
		imagetouch=(ImageView)findViewById(R.id.image);
		custombarclick = (LinearLayout) findViewById(R.id.customfilternew);
		btFilter.setOnClickListener(this);
		findLayout.setOnClickListener(this);
		sliderbutton.setOnClickListener(this);
		custombarclick.setOnClickListener(this);
		initializeAnimations();
		
	}
	
	private void initializeAnimations() {

		final ViewTreeObserver filterObserver = filterLayout
				.getViewTreeObserver();

		filterObserver.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {

			@Override
			public void onGlobalLayout() {
				filterLayout.getViewTreeObserver()
						.removeGlobalOnLayoutListener(this);

				DisplayMetrics displayMetrics = getResources()
						.getDisplayMetrics();

				int deviceWidth = displayMetrics.widthPixels;

				int filterLayoutWidth = (deviceWidth * 80) / 100; // here im

				RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
						filterLayoutWidth,
						RelativeLayout.LayoutParams.MATCH_PARENT);

				filterLayout.setLayoutParams(params);// here im setting the

				filterAnimation.initializeFilterAnimations(filterLayout);

			}
		});

		final ViewTreeObserver findObserver = findLayout.getViewTreeObserver();

		findObserver.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {

			@Override
			public void onGlobalLayout() {
				findLayout.getViewTreeObserver().removeGlobalOnLayoutListener(
						this);

				filterAnimation.initializeOtherAnimations(findLayout);
			}
		});

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int id = v.getId();
		switch (id) {
		case R.id.filter:
			filterAnimation.toggleSliding();
			custombarclick.setVisibility(View.VISIBLE);
			
			
			
			
			ischeck = true;
			if(ischeck == true){
				imagetouch.setBackgroundResource(R.drawable.buttonarrow);
				ischeck = false;
			}else {
				imagetouch.setBackgroundResource(R.drawable.btnmore);
			}
			
			
			
			
			
			break;
		case R.id.btn_Profile:
			filterAnimation.toggleSliding();
			custombarclick.setVisibility(View.GONE);
			Toast.makeText(MainActivity.this, "close", Toast.LENGTH_LONG).show();
			break;
			
			
		case R.id.customfilternew:
		

			if (filterAnimation.isOtherSlideOut) {
				filterAnimation.toggleSliding();
				custombarclick.setVisibility(View.VISIBLE);
				imagetouch.setBackgroundResource(R.drawable.buttonarrow);

			} else {
				custombarclick.setVisibility(View.GONE);
				imagetouch.setBackgroundResource(R.drawable.btnmore);
			}
			
			
			if(ischeck == true){
				imagetouch.setBackgroundResource(R.drawable.buttonarrow);
				ischeck = false;
			}else {
				imagetouch.setBackgroundResource(R.drawable.btnmore);
			}
			

			break;
			
//		case R.id.customfilternew:
//			
//			
//			brteak;
			
		default:
			break;
			
		}
	}
}
